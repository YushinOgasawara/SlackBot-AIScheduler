import asyncio
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

from config.settings import Settings
from models.schedule_models import ScheduleInfo

logger = logging.getLogger(__name__)

class CalendarHandler:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.calendar_service = self._build_calendar_service()
    
    def _build_calendar_service(self):
        """Google Calendar API サービスを構築"""
        try:
            credentials = Credentials.from_service_account_file(
                self.settings.GOOGLE_SERVICE_ACCOUNT_FILE,
                scopes=['https://www.googleapis.com/auth/calendar']
            )
            
            service = build('calendar', 'v3', credentials=credentials)
            return service
            
        except Exception as e:
            logger.error(f"Error building calendar service: {e}")
            return None
    
    async def create_event(self, schedule_info: ScheduleInfo) -> Dict[str, Any]:
        """カレンダーイベントを作成"""
        try:
            event_data = {
                'summary': schedule_info.title,
                'description': schedule_info.description,
                'start': {
                    'dateTime': schedule_info.start_time.isoformat(),
                    'timeZone': 'Asia/Tokyo',
                },
                'end': {
                    'dateTime': schedule_info.end_time.isoformat(),
                    'timeZone': 'Asia/Tokyo',
                },
                'attendees': [
                    {'email': email} for email in schedule_info.attendees
                ] if schedule_info.attendees else [],
                'location': schedule_info.location,
                'reminders': {
                    'useDefault': False,
                    'overrides': [
                        {'method': 'email', 'minutes': 24 * 60},
                        {'method': 'popup', 'minutes': 10},
                    ],
                },
            }
            
            if schedule_info.location:
                event_data['location'] = schedule_info.location
            
            loop = asyncio.get_event_loop()
            event = await loop.run_in_executor(
                None, 
                self._create_event_sync, 
                event_data
            )
            
            return {
                'id': event['id'],
                'title': event['summary'],
                'start_time': event['start']['dateTime'],
                'end_time': event['end']['dateTime'],
                'html_link': event['htmlLink']
            }
            
        except Exception as e:
            logger.error(f"Error creating calendar event: {e}")
            raise
    
    def _create_event_sync(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """同期的にイベントを作成"""
        try:
            event = self.calendar_service.events().insert(
                calendarId='primary',
                body=event_data
            ).execute()
            
            logger.info(f"Calendar event created: {event.get('htmlLink')}")
            return event
            
        except HttpError as error:
            logger.error(f"HTTP error creating event: {error}")
            raise
    
    async def check_availability(self, start_time: datetime, end_time: datetime) -> bool:
        """指定時間帯の空き状況をチェック"""
        try:
            time_min = start_time.isoformat()
            time_max = end_time.isoformat()
            
            loop = asyncio.get_event_loop()
            events = await loop.run_in_executor(
                None,
                self._get_events_sync,
                time_min,
                time_max
            )
            
            return len(events) == 0
            
        except Exception as e:
            logger.error(f"Error checking availability: {e}")
            return True
    
    def _get_events_sync(self, time_min: str, time_max: str) -> List[Dict[str, Any]]:
        """同期的にイベントを取得"""
        try:
            events_result = self.calendar_service.events().list(
                calendarId='primary',
                timeMin=time_min,
                timeMax=time_max,
                singleEvents=True,
                orderBy='startTime'
            ).execute()
            
            events = events_result.get('items', [])
            return events
            
        except HttpError as error:
            logger.error(f"HTTP error getting events: {error}")
            return []
    
    async def update_event(self, event_id: str, schedule_info: ScheduleInfo) -> Dict[str, Any]:
        """イベントを更新"""
        try:
            event_data = {
                'summary': schedule_info.title,
                'description': schedule_info.description,
                'start': {
                    'dateTime': schedule_info.start_time.isoformat(),
                    'timeZone': 'Asia/Tokyo',
                },
                'end': {
                    'dateTime': schedule_info.end_time.isoformat(),
                    'timeZone': 'Asia/Tokyo',
                },
                'attendees': [
                    {'email': email} for email in schedule_info.attendees
                ] if schedule_info.attendees else [],
                'location': schedule_info.location,
            }
            
            loop = asyncio.get_event_loop()
            event = await loop.run_in_executor(
                None,
                self._update_event_sync,
                event_id,
                event_data
            )
            
            return {
                'id': event['id'],
                'title': event['summary'],
                'start_time': event['start']['dateTime'],
                'end_time': event['end']['dateTime'],
                'html_link': event['htmlLink']
            }
            
        except Exception as e:
            logger.error(f"Error updating calendar event: {e}")
            raise
    
    def _update_event_sync(self, event_id: str, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """同期的にイベントを更新"""
        try:
            event = self.calendar_service.events().update(
                calendarId='primary',
                eventId=event_id,
                body=event_data
            ).execute()
            
            logger.info(f"Calendar event updated: {event.get('htmlLink')}")
            return event
            
        except HttpError as error:
            logger.error(f"HTTP error updating event: {error}")
            raise
    
    async def delete_event(self, event_id: str) -> bool:
        """イベントを削除"""
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                self._delete_event_sync,
                event_id
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Error deleting calendar event: {e}")
            return False
    
    def _delete_event_sync(self, event_id: str):
        """同期的にイベントを削除"""
        try:
            self.calendar_service.events().delete(
                calendarId='primary',
                eventId=event_id
            ).execute()
            
            logger.info(f"Calendar event deleted: {event_id}")
            
        except HttpError as error:
            logger.error(f"HTTP error deleting event: {error}")
            raise