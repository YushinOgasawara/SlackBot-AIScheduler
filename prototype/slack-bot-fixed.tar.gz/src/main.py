from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.responses import JSONResponse
import uvicorn
import asyncio
import logging
import os
from typing import Dict, Any

from handlers.slack_handler import SlackHandler
from handlers.schedule_analyzer import ScheduleAnalyzer
from handlers.calendar_handler import CalendarHandler
from config.settings import Settings
from utils.slack_verification import SlackVerification
from utils.logger import setup_logger

app = FastAPI(title="SlackBot-AIScheduler", version="1.0.0")

settings = Settings()
logger = setup_logger()

slack_handler = SlackHandler(settings)
schedule_analyzer = ScheduleAnalyzer(settings)
calendar_handler = CalendarHandler(settings)
slack_verification = SlackVerification(settings)

@app.get("/")
async def root():
    return {"message": "SlackBot-AIScheduler is running"}

@app.get("/health")
async def health():
    return {"status": "healthy"}

@app.post("/slack/events")
async def slack_events(request: Request, background_tasks: BackgroundTasks):
    body = await request.body()
    headers = request.headers
    
    if not slack_verification.verify_signature(body, headers):
        raise HTTPException(status_code=401, detail="Invalid signature")
    
    payload = await request.json()
    
    if payload.get("type") == "url_verification":
        return {"challenge": payload.get("challenge")}
    
    if payload.get("type") == "event_callback":
        event = payload.get("event", {})
        if event.get("type") == "app_mention":
            background_tasks.add_task(process_mention_event, event)
    
    return {"status": "ok"}

async def process_mention_event(event: Dict[str, Any]):
    try:
        logger.info(f"Processing mention event: {event}")
        
        thread_messages = await slack_handler.get_thread_messages(
            event["channel"], event.get("thread_ts", event["ts"])
        )
        
        schedule_info = await schedule_analyzer.analyze_schedule(thread_messages)
        
        if schedule_info and schedule_info.confidence > 0.7:
            calendar_event = await calendar_handler.create_event(schedule_info)
            
            await slack_handler.send_success_message(
                event["channel"],
                event.get("thread_ts", event["ts"]),
                calendar_event
            )
        else:
            await slack_handler.send_error_message(
                event["channel"],
                event.get("thread_ts", event["ts"]),
                "スケジュールの解析に失敗しました。"
            )
    
    except Exception as e:
        logger.error(f"Error processing mention event: {e}")
        await slack_handler.send_error_message(
            event["channel"],
            event.get("thread_ts", event["ts"]),
            f"エラーが発生しました: {str(e)}"
        )

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    logger.info(f"Starting server on port {port}")
    uvicorn.run(app, host="0.0.0.0", port=port)